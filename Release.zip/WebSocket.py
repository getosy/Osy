import websocket

def send_message():
    websocket_url = "ws://localhost:2525"
    ws = websocket.create_connection(websocket_url)
    ws.send('print("Hello, World!")')
    ws.close()

if __name__ == "__main__":
    send_message()
